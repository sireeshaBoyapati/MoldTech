
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DelOp")
public class DelOp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DelOp() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("welcome");
		int v=Integer.parseInt(request.getParameter("s_no"));
		PrintWriter out = response.getWriter();
		try{
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection conn = DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:XE","system","system");
		
		Statement st = conn.createStatement();
		int i = st.executeUpdate("DELETE quest_detail WHERE s_no ="+v+"");
		if(i>0)
		{
			out.println("deleted succesfully");
		}
		conn.close();
		}
		catch(Exception e){
		    out.print(e.getMessage());
	    }
	}

}
