package login;

import java.io.*;  
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;  
  
@WebServlet("/Login")
public class Login extends HttpServlet {  
  
public void doPost(HttpServletRequest request, HttpServletResponse response)  
        throws ServletException, IOException {  
  
    response.setContentType("text/html");  
    PrintWriter out = response.getWriter();  
          
    String userName =request.getParameter("userName");  
    String userPass =request.getParameter("userPass");  
          
    if(userName==null&&userPass==null)
    {
        out.print("welcome");
        RequestDispatcher rs = request.getRequestDispatcher("checkin.html");
        rs.forward(request, response);           
    }
    
    else
    {
       out.println("<h3>Username or Password incorrect</h3>");
       RequestDispatcher rs = request.getRequestDispatcher("login.html");
       rs.include(request, response);
    }
    }  
  
}  
